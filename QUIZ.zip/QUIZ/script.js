var button = document.querySelector('button');
button.addEventListener('click' , function() {
	var totalmarks = 3;
	var currentmarks = 0;
	var youranswer = 0;
	var question1 =  document.getElementById('one').value;
	var question2 =  document.getElementById('two').value;
	var question3 =  document.getElementById('three').value;
	var result = document.getElementById('result');
	var myanswer = document.getElementById('totale');
	if (question1 === "q1a") {
		youranswer++;	
		currentmarks++;
		alert('right');	
	}
	  if(question2 === "q2a"){
		youranswer++;
		currentmarks++;	
	}
	  if (question3 === "q3a") {
		youranswer++;
		currentmarks++;
	
	}else{
		alert('WRONG ANSWER!');
	}
		result.innerHTML = `${'YOUR MARKS: ' + currentmarks}`
		myanswer.innerHTML = `${'Total Correct Answer : ' + youranswer}`
})